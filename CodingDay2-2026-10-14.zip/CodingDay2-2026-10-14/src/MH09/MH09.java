package MH09;


import java.util.*;
public class MH09 {

	/** See printed instructions for a description of this method. */
	public static String shiftLetters(String input) {
		// TODO: Implement this method
		throw new UnsupportedOperationException("Not yet implemented");
	}

	/** See printed instructions for a description of this method. */
	public static int addOnlyDigits(String input) {
		// TODO: Implement this method
		throw new UnsupportedOperationException("Not yet implemented");
	}

	/** See printed instructions for a description of this method. */
	public static String wrapTillX(String input) {
		// TODO: Implement this method
		throw new UnsupportedOperationException("Not yet implemented");
	}

	/** See printed instructions for a description of this method. */
	public static void addThroughArray(int[] array, int from, int to, int amountToAdd) {
		// TODO: Implement this method
		throw new UnsupportedOperationException("Not yet implemented");
	}
}
