package MH10_REF_004.starter;

/**
 * This class represents a Car with 4 wheels, a max of 5 passengers
 * and a variable number of cylinders.  Cylinders may be "hollowed"
 * out, effectively removing cylinders.
 */
public class Car {
    private static final int MAX_CAR_PASSENGERS = 5;

    private int numWheels;
    private int numMilesTraveled;
    private int numPassengers;
    private int numCylinders;

    public Car(int numCylinders) {
        this.numWheels = 4;
        this.numPassengers = 0;
        this.numMilesTraveled = 0;
        this.numCylinders = numCylinders;
    }

    public int getNumWheels() { return this.numWheels; }
    public int getNumMilesTraveled() { return this.numMilesTraveled; }
    public int getNumPassengers() { return this.numPassengers; }
    public int getNumCylinders() { return this.numCylinders; }

    public void travelBy(int miles) {
        this.numMilesTraveled += miles;
    }

    public void service() {
        this.numMilesTraveled = 0;
    }

    public String hollowCylinder(int howMany) {
        if(this.numCylinders > howMany) {
            this.numCylinders -= howMany;
            return this.getClass().getSimpleName() + " hollowed " + howMany + " cylinder(s).";
        }

        return "Cannot hollow that many cylinders! No action taken.";
    }

    public String addPassengers(int numToAdd) {
        if((this.numPassengers + numToAdd) <= MAX_CAR_PASSENGERS) {
            this.numPassengers += numToAdd;
            return this.getClass().getSimpleName() + " added " + numToAdd + " passenger(s).";

        }
        return "This " + this.getClass().getSimpleName() + " can only have " +
                    MAX_CAR_PASSENGERS + " passengers! No action taken.";
    }

    @Override
    public String toString() {
        String toReturn = this.getClass().getSimpleName() +  " has " + this.numWheels +
                " wheels, " + this.numPassengers + " passengers currently, and has traveled " +
                this.numMilesTraveled + " miles since last service.";

        toReturn += " This " + this.getClass().getSimpleName() +  " has " + this.numCylinders +
                " cylinders.";

        return toReturn;
    }
}
