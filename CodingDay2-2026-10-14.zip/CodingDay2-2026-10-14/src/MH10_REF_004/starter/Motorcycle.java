package MH10_REF_004.starter;

/**
 * This class represents a Motorcycle with 2 wheels, a max of 2 passengers
 * and a variable sized engine in CCs.  Engines may be (somehow) "shaved"
 * effectively reducing the size of the engine in CCs.
 */
public class Motorcycle {
    private static final int MAX_BIKE_PASSENGERS = 2;

    private int numWheels;
    private int numMilesTraveled;
    private int numPassengers;
    private int motorSizeInCC;

    public Motorcycle(int motorSizeInCC) {
        this.numWheels = 2;
        this.numMilesTraveled = 0;
        this.numPassengers = 0;
        this.motorSizeInCC = motorSizeInCC;
    }

    public int getNumWheels() { return this.numWheels; }
    public int getNumMilesTraveled() { return this.numMilesTraveled; }
    public int getNumPassengers() { return this.numPassengers; }
    public int getMotorSizeInCC() { return this.motorSizeInCC; }

    public void travelBy(int miles) {
        this.numMilesTraveled += miles;
    }

    public void service() {
        this.numMilesTraveled = 0;
    }

    public String shaveMotor(int downsize) { //we know... not really possible
        if(this.motorSizeInCC > downsize) {
            this.motorSizeInCC -= downsize;
            return this.getClass().getSimpleName() + " shaved " + downsize + "cc('s) of motor.";
        }

        return "Cannot shave that much motor! No action taken.";
    }

    public String addPassengers(int numToAdd) {
        if((this.numPassengers + numToAdd) <= MAX_BIKE_PASSENGERS) {
            this.numPassengers += numToAdd;
            return this.getClass().getSimpleName() + " added " + numToAdd + " passenger(s).";
        }
        return "This " + this.getClass().getSimpleName() + " can only have " +
                    MAX_BIKE_PASSENGERS + " passengers! No action taken.";

    }

    @Override
    public String toString() {
        String toReturn = this.getClass().getSimpleName() +  " has " + this.numWheels +
                " wheels, " + this.numPassengers + " passengers currently, and has traveled " +
                this.numMilesTraveled + " miles since last service.";

        toReturn += " This " + this.getClass().getSimpleName() +  " has " + this.motorSizeInCC +
                " size motor (currently).";

        return toReturn;
    }
}
