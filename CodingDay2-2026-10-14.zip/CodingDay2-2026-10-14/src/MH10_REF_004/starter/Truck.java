package MH10_REF_004.starter;

/**
 * This class represents a Truck with 4 wheels, a max of 10 passengers
 * and a variable sized truck bed in square feet.  The bed of the truck
 * may be cut, effectively reducing the size of the bed in square feet.
 */
public class Truck {
    private static final int MAX_TRUCK_PASSENGERS = 10; //lots of bed space

    private int numWheels;
    private int numMilesTraveled;
    private int numPassengers;
    private int truckBedSquareFootage;

    public Truck(int truckBedSquareFootage) {
        this.numWheels = 4;
        this.numMilesTraveled = 0;
        this.numPassengers = 0;
        this.truckBedSquareFootage = truckBedSquareFootage;
    }

    public int getNumWheels() { return this.numWheels; }
    public int getNumMilesTraveled() { return this.numMilesTraveled; }
    public int getNumPassengers() { return this.numPassengers; }
    public int getTruckBedSquareFootage() { return this.truckBedSquareFootage; }

    public void travelBy(int miles) {
        this.numMilesTraveled += miles;
    }

    public void service() {
        this.numMilesTraveled = 0;
    }

    public String cutBed(int numSquareFootageToCut) {
        if(this.truckBedSquareFootage > numSquareFootageToCut) {
            this.truckBedSquareFootage -= numSquareFootageToCut;
            return this.getClass().getSimpleName() + " cut " + numSquareFootageToCut +
                    " square feet of the bed.";
        }

        return "Cannot cut that much bed! No action taken.";
    }

    public String addPassengers(int numToAdd) {
        if((this.numPassengers + numToAdd) <= MAX_TRUCK_PASSENGERS) {
            this.numPassengers += numToAdd;
            return this.getClass().getSimpleName() + " added " + numToAdd + " passenger(s).";
        }

        return "This " + this.getClass().getSimpleName() + " can only have " +
                    MAX_TRUCK_PASSENGERS + " passengers! No action taken.";
    }

    @Override
    public String toString() {
        String toReturn = this.getClass().getSimpleName() +  " has " + this.numWheels +
                " wheels, " + this.numPassengers + " passengers currently, and has traveled " +
                this.numMilesTraveled + " miles since last service.";

        toReturn += " This " + this.getClass().getSimpleName() +  " has " + this.truckBedSquareFootage +
                " square footage in the bed.";

        return toReturn;
    }
}
