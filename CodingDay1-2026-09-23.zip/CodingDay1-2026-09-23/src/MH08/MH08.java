package MH08;

import java.util.HashMap;
import java.util.ArrayList;

import java.util.*;
public class MH08 {

	/** See printed instructions for a description of this method. */
	public static String highestAverage(HashMap<String, ArrayList<Integer>> namesToGrades) {
		// TODO: Implement this method
		throw new UnsupportedOperationException("Not yet implemented");
	}

	/** See printed instructions for a description of this method. */
	public static ArrayList<String> definitionContains(HashMap<String, String> dictionary, String termToFind) {
		// TODO: Implement this method
		throw new UnsupportedOperationException("Not yet implemented");
	}

	/** See printed instructions for a description of this method. */
	public static String findMismatch(String[] names, Integer[] ages) {
		// TODO: Implement this method
		throw new UnsupportedOperationException("Not yet implemented");
	}

	/** See printed instructions for a description of this method. */
	public static double classAverage(HashMap<String, Integer> gradesMap) {
		// TODO: Implement this method
		throw new UnsupportedOperationException("Not yet implemented");
	}
}
