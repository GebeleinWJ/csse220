package MH07;

import java.util.ArrayList;

import java.util.*;
public class MH07 {

	/** See printed instructions for a description of this method. */
	public static String removeUpperCase(String input) {
		// TODO: Implement this method
		throw new UnsupportedOperationException("Not yet implemented");
	}

	/** See printed instructions for a description of this method. */
	public static int productOfDiagonal(int[][] matrix) {
		// TODO: Implement this method
		throw new UnsupportedOperationException("Not yet implemented");
	}

	/** See printed instructions for a description of this method. */
	public static ArrayList<Integer> dailyChanges(int[] balances) {
		// TODO: Implement this method
		throw new UnsupportedOperationException("Not yet implemented");
	}

	/** See printed instructions for a description of this method. */
	public static ArrayList<String> findLinkedWords(String[] words) {
		// TODO: Implement this method
		throw new UnsupportedOperationException("Not yet implemented");
	}
}
